package com.salesforce.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.testleaf.testng.api.base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {
	public HomePage() {
		PageFactory.initElements(getDriver(), this);
		
	}

	@FindBy(how = How.XPATH, using = "//div[@class='slds-global-header__item']//li[4]//a")
	private WebElement actionIcon;

//	click Actions (SVG) Icon
	public HomePage clickActionsIcon() {
		click(actionIcon); 
		return this;
	}

	@FindBy(how = How.XPATH, using = "(//span[text()='New Event'])[1]")
	private WebElement newEvent;

//	Click on New Event
	public HomePage newEvent() throws InterruptedException {
		hoverAndClick(newEvent);
		return this;
	}

	@FindBy(how = How.XPATH, using = "//button[@title='Maximize']")
	private WebElement eleMax;

//	To maximize the prompt
	public HomePage maximizeIt() throws InterruptedException {
		Thread.sleep(3000);
		hoverAndClick(eleMax);
		reportStep("maximized successfully", "pass");
		return this;
	}

	@FindBy(how = How.XPATH, using = "(//span[text()='Save'])[2]")
	private WebElement eleSave;

//	To click the save button
	public HomePage clickSaveButton() {
		click(eleSave);
		return this;
	}

}
