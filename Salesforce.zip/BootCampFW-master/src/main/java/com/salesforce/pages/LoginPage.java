package com.salesforce.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.testleaf.selenium.api.base.SeleniumBase;
import com.testleaf.testng.api.base.ProjectSpecificMethods;

import cucumber.api.java.en.Given;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage() {
		PageFactory.initElements(getDriver(), this);	
	} 

	
	@FindBy(how = How.ID, using="username") 
	private WebElement eleUsername;

	public LoginPage enterUsername(String str) {
		clearAndType(eleUsername, str);
		return this;
	}

	@FindBy(how = How.ID, using="password") 
	private WebElement elePassword;
	public LoginPage enterPassword(String str) {
		clearAndType(elePassword, str);
		return this;
	}

	@FindBy(how = How.CSS, using="input#Login") 
	private WebElement eleLoginButton;
	public HomePage clickLogin() throws InterruptedException {
		click(eleLoginButton);
		Thread.sleep(5000);
		return new HomePage();
	}

	
}
