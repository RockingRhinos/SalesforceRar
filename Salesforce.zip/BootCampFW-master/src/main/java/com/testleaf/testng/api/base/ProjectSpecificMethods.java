package com.testleaf.testng.api.base;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.testleaf.selenium.api.base.SeleniumBase;
import com.testleaf.utils.DataLibrary;

public class ProjectSpecificMethods extends SeleniumBase {
	public static String typedText;

	@DataProvider(name = "fetchData")
	public Object[][] fetchData() throws IOException {
		return DataLibrary.readExcelData(excelFileName);
	}	

	@Parameters({"browser"})
	@BeforeMethod(alwaysRun = true)
	public void beforeMethod(String browser) {
		startApp(browser, "https://login.salesforce.com/");
	
		setNode();
	}

	@AfterMethod()
	public void afterMethod() {	
		close();
	}













}
